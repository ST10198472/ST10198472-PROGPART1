/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;

/**
 *
 * @author ST10198472 Emihle Mhambi
 */
public class Login {
    private final String username;
    private final String password;
    private final String firstName;
    private final String lastName;

    public Login(String username, String password, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Method to check if username format is correct
    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    // Method to check password complexity
    public boolean checkPasswordComplexity() {
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;
        String specialCharacters = "!@#$%^&*()-+";

        if (password.length() < 8)
            return false;

        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch))
                hasCapital = true;
            if (Character.isDigit(ch))
                hasNumber = true;
            if (specialCharacters.contains(String.valueOf(ch)))
                hasSpecialChar = true;
        }

        return hasCapital && hasNumber && hasSpecialChar;
    }

    // Method to register user and return registration message
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is incorrectly formatted.";
        } else if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and special character.";
        } else {
            return "User registered successfully.";
        }
    }

    // Method to authenticate user login
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }

    // Method to return login status message
    public String returnLoginStatus(boolean isAuthenticated) {
        if (isAuthenticated) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
