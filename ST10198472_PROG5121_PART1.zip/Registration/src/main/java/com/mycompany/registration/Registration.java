/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;
import java.util.Scanner;
/**
 *
 * @author ST10198472 Emihle Mhambi
 */
public class Registration {
 
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
     System.out.println("*****Welcome to User Registration and Login*****");
        // Registration
        //Ask user to enter username
        System.out.print("Enter username: ");
        String username = reader.nextLine();
        //Ask user to enter password
        System.out.print("Enter password: ");
        String password = reader.nextLine();
        //Ask user to enter first name 
        System.out.print("Enter first name: ");
        String firstName = reader.nextLine();
        //Ask user to enter their last name
        System.out.print("Enter last name: ");
        String lastName = reader.nextLine();

        Login newUser = new Login(username, password, firstName, lastName);
        String registrationMessage = newUser.registerUser();
        System.out.println(registrationMessage);

        if (registrationMessage.equals("User registered successfully.")) {
            // Login
            System.out.println("Login to your account");
            System.out.print("Enter username: ");
            String enteredUsername = reader.nextLine();

            System.out.print("Enter password: ");
            String enteredPassword = reader.nextLine();

            boolean isAuthenticated = newUser.loginUser(enteredUsername, enteredPassword);
            String loginStatus = newUser.returnLoginStatus(isAuthenticated);
            System.out.println(loginStatus);
        }   
    }
}
