/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.registration;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ST10198472 Emihle Mhambi
 */
public class RegistrationTest {
    
    public RegistrationTest() {
    }

    @org.junit.jupiter.api.Test
    public void testSomeMethod() {
    }
    @Test
    public void testCheckUserName_Valid() {
        Login login = new Login("user_1", "Password1@", "John", "Doe");
        assertTrue(login.checkUserName());}
    
     @Test
    public void testCheckUserName_Invalid() {
        Login login = new Login("user", "Password1@", "John", "Doe");
        assertFalse(login.checkUserName());
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        Login login = new Login("user_1", "Password1@", "John", "Doe");
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testCheckPasswordComplexity_Invalid() {
        Login login = new Login("user_1", "password", "John", "Doe");
        assertFalse(login.checkPasswordComplexity());
    }

    @Test
    public void testRegisterUser_Successful() {
        Login login = new Login("user_1", "Password1@", "John", "Doe");
        assertEquals("User registered successfully.", login.registerUser());
    }

    @Test
    public void testRegisterUser_InvalidUsername() {
        Login login = new Login("user", "Password1@", "John", "Doe");
        assertEquals("Username is incorrectly formatted.", login.registerUser());
    }

    @Test
    public void testRegisterUser_InvalidPassword() {
        Login login = new Login("user_1", "password", "John", "Doe");
        assertEquals("Password does not meet complexity requirements.", login.registerUser());
    }

    @Test
    public void testLoginUser_Successful() {
        Login login = new Login("user_1", "Password1@", "John", "Doe");
        assertTrue(login.loginUser("user_1", "Password1@"));
    }

    @Test
    public void testLoginUser_Failed() {
        Login login = new Login("user_1", "Password1@", "John", "Doe");
        assertFalse(login.loginUser("user_1", "wrongpassword"));
    }

    @Test
    public void testReturnLoginStatus_Successful() {
        Login login = new Login("user_1", "Password1@", "John", "Doe");
        assertEquals("Welcome John Doe, it is great to see you again.", login.returnLoginStatus(true));
    }

    @Test
    public void testReturnLoginStatus_Failed() {
        Login login = new Login("user_1", "Password1@", "John", "Doe");
        assertEquals("Username or password incorrect, please try again.", login.returnLoginStatus(false));
    }
}
